package Timer;

import java.beans.PropertyChangeListener;

public interface TimerChangeListener extends PropertyChangeListener
{
    String EVENT = "seconde" ;

    // cette méthode sera supprimé et remplacé par celle provenant du PropertyChangeListener


}
