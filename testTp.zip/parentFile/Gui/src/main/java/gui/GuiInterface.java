package gui;

import Robot.Robot;

import javax.swing.*;
import java.awt.*;
import Timer.TimerChangeListener;
import lookup.Lookup;

import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;


public class GuiInterface extends JFrame implements TimerChangeListener {

    Robot r = Lookup.getInstance().getService(Robot.class);
    Environement environement = new Environement();


    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.translate(50,50);
        Color color = Color.BLACK;
        for(int row = 0 ; row<environement.getMaez().length;row++) {
            for (int col = 0; col < environement.getMaez().length; col++) {
                switch (environement.getMaez()[row][col]) {
                    case 1:
                        color = Color.BLACK;break;
                    case 0:
                        color = Color.WHITE;break;
                    default:break;
                }
                g.setColor(color);
                g.fillRect(30 * col, 30 * row, 30, 30);
                g.setColor(Color.BLACK);
                g.drawRect(30 * col, 30 * row, 30, 30);
                Color color1 = Color.GREEN;
                int x = r.getX();
                int  y = r.getY();
                g.setColor(Color.red);

                g.fillOval(30 * y, 30 * x, 30, 30);
            }
        }
    }

    JFrame frame = new JFrame("GuiInterface");
    JButton upButton = new JButton("^");
    JButton downButton = new JButton("v");
    JButton leftButton = new JButton("<-");
    JButton righteButton = new JButton("->");
    JLabel xLabel = new JLabel();
    JLabel yLabel = new JLabel();
    JLabel directionLabel = new JLabel();
    JLabel obstacleLabele = new JLabel();
    JLabel right = new JLabel();
    JLabel left = new JLabel();
    JLabel up = new JLabel();
    JLabel down = new JLabel();



    public void update() {

            downButton.setBackground(Color.white);
            upButton.setBackground(Color.white);
            leftButton.setBackground(Color.white);
            righteButton.setBackground(Color.white);
            Color color1 = Color.GREEN;
            int x = r.getX();
            int y = r.getY();
            getGraphics().setColor(color1);
            getGraphics().fillRect(30 * (y + 50), 30 * (x + 50), 30, 30);
            xLabel.setText(String.valueOf(x));
            yLabel.setText(String.valueOf(y));
            this.positionUpdate(x,y);
        }
        public void positionUpdate(int x,int y){

            if (r.getName() == "right") {
                righteButton.setBackground(Color.red);
                System.out.println(" x " + x + " y  :" + y);
                System.out.println("Perdqment Right");
                x++;
                if (x < environement.getMaez().length && y < environement.getMaez().length && x > -1 && y > -1 && environement.getMaez()[x][y] != 1) // bcz 1 mean block
                {
                    r.setX(x);
                }
            }

            if (r.getName() == "left") {
                leftButton.setBackground(Color.red);
                System.out.println(" x " + x + " y  :" + y);
                System.out.println("Perdqment left");
                x--;

                if (x < environement.getMaez().length && y < environement.getMaez().length && x > -1 && y > -1 && environement.getMaez()[x][y] != 1) // bcz 1 mean block
                {
                    r.setX(x);
                }

            }
            if (r.getName() == "up") {
                upButton.setBackground(Color.red);

                System.out.println(" x " + x + " y  :" + y);
                System.out.println("Perdqment up");

                y++;

                if (x < environement.getMaez().length && y < environement.getMaez().length && x > -1 && y > -1 && environement.getMaez()[x][y] != 1) // bcz 1 mean block
                {
                    r.setY(y);
                }
            }
            if (r.getName() == "down") {
                downButton.setBackground(Color.red);
                System.out.println(" x " + x + " y  :" + y);
                System.out.println("Perdqment down");

                y--;

                if (x < environement.getMaez().length && y < environement.getMaez().length && x > -1 && y > -1 && environement.getMaez()[x][y] != 1) // bcz 1 mean block
                {
                    r.setY(x);
                }
            }
        }
    public GuiInterface(){
        frame.add(upButton);
        upButton.setBounds(10,10,50,50);
        frame.add(downButton);
        downButton.setBounds(10,60,50,50);
        frame.add(leftButton);
        leftButton.setBounds(10,110,50,50);
        frame.add(righteButton);
        righteButton.setBounds(10,160,50,50);


        right.setText(  "right button take u down");
        right.setBounds(200,200,400,200);
        right.setOpaque(true);
        right.setHorizontalAlignment(JTextField.CENTER);
        frame.add(right);
        

        left.setText( "Up button take u righte");
        left.setBounds(50,50,400,200);
        left.setOpaque(true);
        left.setHorizontalAlignment(JTextField.CENTER);
        frame.add(left);

        xLabel.setText("0");
        xLabel.setBounds(10,200,50,50);
        xLabel.setFont(new Font("Verdana",Font.PLAIN,35));
        xLabel.setBorder(BorderFactory.createBevelBorder(1));
        xLabel.setOpaque(true);
        xLabel.setHorizontalAlignment(JTextField.CENTER);
        frame.add(xLabel);
        yLabel.setText("0");
        yLabel.setBounds(10,260,50,50);
        yLabel.setFont(new Font("Verdana",Font.PLAIN,35));
        yLabel.setBorder(BorderFactory.createBevelBorder(1));
        yLabel.setOpaque(true);
        yLabel.setHorizontalAlignment(JTextField.CENTER);
        frame.add(yLabel);
        frame.add(directionLabel);
        frame.add(obstacleLabele);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        frame.setLayout(null);
        frame.setVisible(true);


        setTitle("maze");
        setSize(640,480);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    @Override
    protected void processKeyEvent(KeyEvent e) {
        super.processKeyEvent(e);
        if(e.getID()!= KeyEvent.KEY_PRESSED)
            return;
        if(e.getKeyCode() == KeyEvent.VK_RIGHT)
        {
            r.right();
            System.out.println("go Right");
        }
        else if (e.getKeyCode() == KeyEvent.VK_LEFT)
        {
            r.left();
            System.out.println("go left");
        }
        else if (e.getKeyCode() == KeyEvent.VK_UP)
        {
            System.out.println("go up");
            r.up();
        }
        else if (e.getKeyCode() == KeyEvent.VK_DOWN)
        {
            System.out.println("go down");
            r.down();
        }
    }

    public JButton getUpButton() {
        return upButton;
    }

    public JButton getDownButton() {
        return downButton;
    }

    public JButton getLeftButton() {
        return leftButton;
    }

    public JButton getRighteButton() {
        return righteButton;
    }


    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        this.paint(getGraphics());
        this.update();
    }

}





