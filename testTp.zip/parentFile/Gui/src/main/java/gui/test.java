package gui;

public class test {
    public static void main(String[] args) {
        GuiInterface g = new GuiInterface();
        g.setVisible(true);
    }

}
