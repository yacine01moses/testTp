package Robot;

public class UpState extends RobtoState{

    public UpState(Robot r) {
        super(r);
    }


    @Override
    void up() {

    }

    @Override
    void down() {

        System.out.println("cant go down");
    }

    @Override
    void left() {
        r.setState(new LeftState(r));
    }

    @Override
    void right() {

        r.setState(new RightState(r));

    }
    String name = "up";

    public String getName() {
        return name;
    }

}
