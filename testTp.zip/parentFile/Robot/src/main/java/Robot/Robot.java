package Robot;

import Timer.TimerChangeListener;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class Robot implements TimerChangeListener {

    RobtoState state = new RightState(this);
    private static Robot INSTANCE;
    private int x =0,y=0;
    public void up() {state.up();}
    public void down() {state.down();}
    public void left() {state.left();}
    public void right() {state.right();}
    public void setState(RobtoState s ) { this.state = s;}

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }



    public String getName(){
        return state.getName();
    }

    public Robot()
    {
    };
    public Robot getINSTANCE()
    {
        if(INSTANCE == null)
            INSTANCE = new Robot();
        return INSTANCE;
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {


    }
}
