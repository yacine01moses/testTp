package Robot;

public class LeftState extends RobtoState{
    String name = "left";

    public LeftState(Robot r) {
        super(r);
    }

    @Override
    void up() {
        r.setState(new UpState(r));
    }

    public String getName() {
        return name;
    }

    @Override
    void down() {
        r.setState(new DownState(r));
    }

    @Override
    void left() {

    }

    @Override
    void right() {
        System.out.println("cant go right");
    }
}
