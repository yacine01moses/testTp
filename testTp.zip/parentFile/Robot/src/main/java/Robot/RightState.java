package Robot;

public class RightState extends RobtoState {
    String name = "right";

    public RightState(Robot r) {
        super(r);
    }

    @Override
    void up() {
        r.setState(new UpState(r));
    }

    public String getName() {
        return name;
    }

    @Override
    void down() {
        r.setState(new DownState(r));
    }

    @Override
    void left() {
        System.out.println("cant go left");
    }

    @Override
    void right() {

    }
}