package Robot;


public class DownState extends RobtoState{

    String name = "down";
    public DownState(Robot r) {
        super(r);
    }

    @Override
    void up() {
        System.out.println("cant go up");
    }

    public String getName() {
        return name;
    }

    @Override
    void down() {

    }

    @Override
    void left() {

        r.setState(new LeftState(r));
    }

    @Override
    void right() {

        r.setState(new RightState(r));

    }
}
