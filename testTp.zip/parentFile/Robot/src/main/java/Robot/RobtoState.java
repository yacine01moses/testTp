package Robot;

public abstract class RobtoState {
    Robot r= null;

    public RobtoState(Robot r)
    {
        this.r=r;
    }
    abstract void up();
    abstract void down();
    abstract void left();
    abstract void right();
    abstract String getName();

}
