package launcher;

import Timer.TimerChangeListener;
import Timer.TimerServiceImplWithDelegation;
import Robot.Robot;
import gui.GuiInterface;
import lookup.Lookup;

import java.awt.*;

public class Main {
    public static void main(String[] args) {
        Lookup.getInstance().register(Robot.class,new Robot());
        Robot r = Lookup.getInstance().getService(Robot.class);
        TimerServiceImplWithDelegation timeservice = new TimerServiceImplWithDelegation();

        GuiInterface gui = new GuiInterface();
        gui.setVisible(true);
        timeservice.addTimeChangeListener(gui);
        timeservice.addTimeChangeListener(r);

    }
}
